/**
 * @author adgangad
 * 
 * Thsi is the controller class
 * This class will recieve the incoming request from the client side and
 *  process the specified request and send it back to the client .
 * 
 * 
 */

package com.cg.TripAdvisor.controller;


import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.TripAdvisor.dto.Destination;
import com.cg.TripAdvisor.dto.Review;
import com.cg.TripAdvisor.exception.DestinationDetailNotFoundException;
import com.cg.TripAdvisor.services.DestinationService;
import com.cg.TripAdvisor.services.DestinationServiceImp;
import com.cg.TripAdvisor.services.ReviewService;


@RestController
@RequestMapping("/tripadvisor")
public class TripAdvisorController {

	private static final Logger logger = Logger.getLogger(DestinationServiceImp.class);
	@Autowired
	DestinationService destinationservice;
	@Autowired
	ReviewService reviewservice;

	/**
	 * This function will add the destination details to the database
	 * @throws DestinationDetailNotFoundException
	 * @param dest type:-Destination
	 * @return destination type:Destination
	 */
	@RequestMapping(value="/addDestination",method=RequestMethod.POST)
	public  ResponseEntity<Destination> addDestination(@ModelAttribute Destination dest) {
		logger.info("entered to the addDestination function in controller");
		Destination destination = null;
		try {
			destination = destinationservice.addDestination(dest);
		} catch (DestinationDetailNotFoundException e) {
			return new ResponseEntity(e.getMessage(),HttpStatus.NOT_FOUND);
		}
		if(destination==null) {
			return new ResponseEntity("Destination not added",HttpStatus.NOT_FOUND);

		}
		return new ResponseEntity<Destination>(destination,HttpStatus.OK);

	}

	/**
	 * This function will add the review  details to the specified destination in database
	 * @author adgangad
	 * @throws DestinationDetailNotFoundException
	 * @param dest type:-Destination
	 * @return destination type:Destination
	 */
	@RequestMapping(value="/addReview",method=RequestMethod.POST)
	public  ResponseEntity<Destination> addReview(@ModelAttribute Review review) {
		logger.info("entered to the addReview function in controller");
		String city = review.getCity();

		Destination destination = destinationservice.searchByCity(review.getCity());

		try {
			review =reviewservice.addReview(review);
		} catch (DestinationDetailNotFoundException e) {
			logger.warn("destination detail not found exception");
			return new ResponseEntity(e.getMessage(),HttpStatus.NOT_FOUND);
		}

		if(review==null) {
			logger.warn("destination not found review null");
			return new ResponseEntity("Destination not found",HttpStatus.NOT_FOUND);	
		}
		return new ResponseEntity<Destination>(destinationservice.searchByCity(review.getCity()),HttpStatus.OK);
	}

	/**
	 * This function will find the review based on the city
	 * @author adgangad
	 * @throws DestinationDetailNotFoundException
	 * @param dest type:-Destination
	 * @return destination type:Destination
	 */
	@RequestMapping(value="/findreview",method=RequestMethod.GET)
	public  ResponseEntity<Destination> findReview(@RequestParam("city") String city) {
		logger.info("entered to the findreview function in controller");
		Destination dest = destinationservice.searchByCity(city);
		System.out.println(dest);
		if(dest==null) {
			logger.warn("destination not found dest null exception thrown");
			return new ResponseEntity("No Review for this destination",HttpStatus.NOT_FOUND);

		}
		return new ResponseEntity<Destination>(dest,HttpStatus.OK);

	}	
	/**
	 * This function will find the destination based on the rating
	 * @author adgangad
	 * @throws DestinationDetailNotFoundException
	 * @param dest type:-Destination
	 * @return destination type:Destination
	 */
	@RequestMapping(value="/finddestination",method=RequestMethod.GET)
	public  ResponseEntity<List<Destination>> findDestination(@RequestParam("rating") int rating) {
		logger.info("entered to the finddestination function in controller");
		List<Destination> destinations = destinationservice.searchDestinationByRating(rating);
		System.out.println(destinations);
		if(destinations.isEmpty()) {
			logger.warn("destination not found destination list empty exception thrown");
			return new ResponseEntity("No Destination Found",HttpStatus.NOT_FOUND);

		}
		return new ResponseEntity<List<Destination>>(destinations,HttpStatus.OK);

	}
}

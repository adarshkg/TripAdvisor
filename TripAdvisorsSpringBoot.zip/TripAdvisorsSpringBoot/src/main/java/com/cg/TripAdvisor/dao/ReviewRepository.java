
/**
 *	
 *This is the interface which extends the JpaRepository which we can do CRUD operations.
 *@author adgangad
 *.
 */
 
package com.cg.TripAdvisor.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.TripAdvisor.dto.Review;

public interface ReviewRepository extends JpaRepository<Review, Integer>{
	/**
	 *  It will find the Reviews using city from the database
	 * @author adgangad
	 * @param city
	 * @return Destination
	 */
		public List<Review> findBycity(String city);
		
}

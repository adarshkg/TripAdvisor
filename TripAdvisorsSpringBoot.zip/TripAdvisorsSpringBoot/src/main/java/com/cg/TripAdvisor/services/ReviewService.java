/**
 *	@author adgangad
 */
package com.cg.TripAdvisor.services;

import java.util.List;

import com.cg.TripAdvisor.dto.Review;
import com.cg.TripAdvisor.exception.DestinationDetailNotFoundException;



public interface ReviewService {
	
	public Review addReview(Review review) throws DestinationDetailNotFoundException ;
	
}

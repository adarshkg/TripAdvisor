/**
 *	
 *This is the interface which extends the JpaRepository which we can do CRUD operations.
 *@author adgangad
 *There are three functions.
 */
package com.cg.TripAdvisor.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import com.cg.TripAdvisor.dto.Destination;


public interface DestinationRepository extends JpaRepository<Destination, Integer> {
/**
 *  It will find the destination using city from the database
 * @author adgangad
 * @param city
 * @return Destination
 */
	public Destination findByCity(String city);
	/**
	 *  It will find the List of destination using rating
	 * @author adgangad
	 * @param city
	 * @return List<Destination>
	 */
	public List<Destination> findByRating(int rating);

	
}

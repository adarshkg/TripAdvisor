/**
 * @author adgangad
 * last modified: 5/27/2019
 * 
 * This is the main class.
 * The spring boot application will start from this class.
 * This will configure everything needed for this application. 
 */


package com.cg.TripAdvisor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.cg.TripAdvisor")
public class TripAdvisorApplication {

/**
 * @author adgangad
 * @param args
 * 
 * 
 */
	public static void main(String[] args) {
		SpringApplication.run(TripAdvisorApplication.class, args);
	}

}

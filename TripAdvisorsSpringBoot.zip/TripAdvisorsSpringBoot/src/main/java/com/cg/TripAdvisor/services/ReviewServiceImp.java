
/** @author adgangad
 * project name: TripAdvisor
 * 			This project is about adding destination and writing  review for the destination
 * One function :-
 * 			
 *	1.addReview()  [parameters-->Review review,String city , return type-->Review review]
 *
 *	Here the data is sending to the repository layer
 * 
 * */

package com.cg.TripAdvisor.services;

import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.TripAdvisor.dao.DestinationRepository;
import com.cg.TripAdvisor.dao.ReviewRepository;
import com.cg.TripAdvisor.dto.Destination;
import com.cg.TripAdvisor.dto.Review;
import com.cg.TripAdvisor.exception.DestinationDetailNotFoundException;


@Service
@Transactional
public class ReviewServiceImp implements ReviewService {
	private static final Logger logger = Logger.getLogger(DestinationServiceImp.class);
	private static int reviewId=30;
	private static int reviewerId=35;

	@Autowired
	DestinationRepository destinationrepository;

	/**
	 * @author adgangad
	 * @param:- 
	 * @return :- review(Review)
	 * @throws DestinationDetailNotFoundException
	 * 	calling the save function from the reveiw repsository class and passing the reveiw and returning the reveiw,
			if the destination is not found then throw DestinationDetailNotFoundException .
	 * @throws DestinationDetailNotFoundException */
	@Override
	public Review addReview(Review review) throws DestinationDetailNotFoundException {
		logger.info("entered to add review function");
		reviewerId++;
		reviewId++;
		review.setId(reviewId);
		review.getReviewer().setId(reviewerId);
		Destination dest=destinationrepository.findByCity(review.getCity());
		if(dest==null) {
			throw new DestinationDetailNotFoundException("No destination found");
		}
		List<Review> reviews = dest.getReview();
		reviews.add(review);
		dest.setReview(reviews);
		destinationrepository.save(dest);
		return review;

	}

}

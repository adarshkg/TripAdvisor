/**
 *@author adgangad
 *
 *
 */
package com.cg.TripAdvisor.services;

import java.util.List;

import com.cg.TripAdvisor.dto.Destination;
import com.cg.TripAdvisor.dto.Review;
import com.cg.TripAdvisor.exception.DestinationDetailNotFoundException;

public interface DestinationService {
	public Destination addDestination(Destination destination) throws DestinationDetailNotFoundException ;
	
	public List<Destination> searchDestinationByRating(int rating) ;
	public Destination searchByCity(String city) ;
}

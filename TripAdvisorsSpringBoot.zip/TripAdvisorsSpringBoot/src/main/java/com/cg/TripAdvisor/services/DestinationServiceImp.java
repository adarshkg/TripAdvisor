/**	@author adgangad
 * project name: TripAdvisor
 * 			This project is about adding destination and writing  review for the destination
 * Three function :-
 * 			
 * 			1.add destination()  [parameters-->Destination destination , return type-->Destination destination]
 *		    2.SearchReviewByDestination() [parameters-->string myDestination,return type---->List of Reviews]
 *			3.SearchDestinationByRating() [parameters-->int rating,return type---->List of Destination]
 * 
 * This class is sending the data to the repository layer and then fetching the details from repository layer
 * */

package com.cg.TripAdvisor.services;

import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.TripAdvisor.dao.DestinationRepository;
import com.cg.TripAdvisor.dto.Destination;
import com.cg.TripAdvisor.exception.DestinationDetailNotFoundException;



@Service
@Transactional
public class DestinationServiceImp implements DestinationService{

	private static final Logger logger = Logger.getLogger(DestinationServiceImp.class);
	private static int destId=25;

	@Autowired
	DestinationRepository destinationrepository;

	/**
	 * 
	 * This function will set a static id for the destination and 
	 * find the destination by city and 
	 * if the the destination is alredy exist it will throw an exception.
	 * 
	 * @author adgangad
	 * @param destination ,type Destination
	 * @return :- Destination
	 * @throws DestinationDetailNotFoundException
	 * */
	@Override
	public Destination addDestination(Destination destination) throws DestinationDetailNotFoundException {

		logger.info("entered to add destination function");
		destId++;
		System.out.println(destId);
		destination.setId(destId);
		Destination dest = destinationrepository.findByCity(destination.getCity());
		if(dest!=null && destination.getCity().equals(dest.getCity())) {
			logger.warn("destination already exist exception thrown");
			throw new DestinationDetailNotFoundException("Destination already exist");
		}
		
		return destinationrepository.save(destination);		
	}


	/**
	 * 
	 * 
	 * @author adgangad
	 * @param:- city ,type:String
	 * @return :- Destination
	 * 	
	 * calling the find function from the repository where searching using destination city and returning 

	 *
	 */

	@Override
	public Destination searchByCity(String city) {
		logger.info("entered to search by city function");
		return destinationrepository.findByCity(city);
	}

	/**
	 * 
	 * 
	 * @author adgangad
	 * @param:- rating , type  int
	 * @return :- List<Destination>
	 * 	
	 * calling the find function from the repository where searching using rating and returning the List of Destination
	 *

	 *
	 */
	
	@Override
	public List<Destination> searchDestinationByRating(int rating) {
		logger.info("entered to search destination by ratingfunction");
		return destinationrepository.findByRating(rating);
	}



}

/**
 *	@author adgangad
 * project name: TripAdvisor
 * This is dto class
 * There are fields int id,String city,String description
 * And one to one relationship with reviewer
 */
package com.cg.TripAdvisor.dto;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Review")
public class Review {

	@Id
	@Column(name="review_id")
	private  int id;
	@Column(name="city")
	private String city;
	@Column(name="review_desc")
	private String description;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="reviewer_id")
	private Reviewer reviewer;
	
	
	
	
	
	
	public Review() {
		super();

	}

	public Review(int id, String city, String description, Reviewer reviewer) {
		super();
		this.id = id;
		this.city = city;
		this.description = description;
		this.reviewer = reviewer;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDescription() {
		return description;
	}




	public void setDescription(String description) {
		this.description = description;
	}




	public Reviewer getReviewer() {
		return reviewer;
	}




	public void setReviewer(Reviewer reviewer) {
		this.reviewer = reviewer;
	}




	

	@Override
	public String toString() {
		return "Review [id=" + id + ", city=" + city + ", description=" + description + ", reviewer=" + reviewer
				;
	}

	

}

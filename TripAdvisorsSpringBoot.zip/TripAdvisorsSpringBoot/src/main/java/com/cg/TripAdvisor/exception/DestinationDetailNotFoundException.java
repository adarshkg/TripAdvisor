/**
 *	@author adgangad
 * project name: TripAdvisor
 * DestinationDetailNotFoundException class which extend from Exceprion
 */
package com.cg.TripAdvisor.exception;

public class DestinationDetailNotFoundException  extends Exception{

	public DestinationDetailNotFoundException() {
		super();
	
	}
	public DestinationDetailNotFoundException(String message) {
		super(message);

	}


	
}

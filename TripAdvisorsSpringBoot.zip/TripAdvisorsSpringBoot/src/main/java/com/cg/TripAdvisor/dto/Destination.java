/**
 *	@author adgangad
 * project name: TripAdvisor
 * This is dto class
 * There are fields int id,String city,int rating,String country
 * And one to many relationship with review
 */

package com.cg.TripAdvisor.dto;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="destination")
public class Destination {
	@Id
	private int id;
	@Column(unique=true,name="dest_city")
	private String city;
	@Column(name="dest_rating")
	private Integer rating;
	@Column(name="dest_country")
	private String country;
	
	@OneToMany(cascade = CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name="dest_id")
	private List<Review> review;
	
	public Destination() {
		super();	
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Destination(int id, String city, Integer rating, String country, List<Review> review) {
		super();
		this.id = id;
		this.city = city;
		this.rating = rating;
		this.country = country;
		this.review = review;
	}



	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Integer getRating() {
		return rating;
	}
	public void setRating(Integer rating) {
		this.rating = rating;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public List<Review> getReview() {
		return review;
	}
	public void setReview(List<Review> review) {
		this.review = review;
	}

	@Override
	public String toString() {
		return "Destination [city=" + city + ", rating=" + rating + ", country=" + country + ", review=" + review + "]";
	}
	
	
	
	
}

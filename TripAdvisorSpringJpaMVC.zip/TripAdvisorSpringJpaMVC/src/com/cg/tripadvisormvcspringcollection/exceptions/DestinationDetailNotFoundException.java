/**
 *	@author adgangad
 *
 *
 *  In this  class exception is thrown from other classes
 *
 */


package com.cg.tripadvisormvcspringcollection.exceptions;

public class DestinationDetailNotFoundException extends Exception {

	public DestinationDetailNotFoundException() {
		super();

	}
	public DestinationDetailNotFoundException(String message) {
	
		super(message);
		
		

	}

}


/**	@author adgangad
 * project name: TripAdvisor
 * 			This project is about adding destination and writing  review for the destination
 * One function :-
 * 			
 *	1.addReview()  [parameters-->Review review,String city , return type-->Review review]
 *
 *	Here the data is sending to the repository layer
 * 
 * */

package com.cg.tripadvisormvcspringcollection.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.tripadvisormvcspringcollection.dto.Review;
import com.cg.tripadvisormvcspringcollection.exceptions.DestinationDetailNotFoundException;
import com.cg.tripadvisormvcspringcollection.repository.ReviewRepositoryImp;
@Service("reviewService")
@Transactional
public class ReviewServiceImp implements ReviewService {
	public static int reviewId=0;
	public static int reviewerId=0;
	@Autowired
	ReviewRepositoryImp reviewRepo;
	
/**
 * @author adgangad
 * @param:- review (Review)
 * @return :- review(Review)
 * @throws DestinationDetailNotFoundException .
 * */
	@Override
	public Review addReview(Review review) {
		reviewId++;
		reviewerId++;
		review.setId(reviewId);
		review.getReviewer().setId(reviewerId);
		Review myReview=reviewRepo.save(review);
		return myReview;

	}

}

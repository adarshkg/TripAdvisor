/*
 *	@author adgangad
 */
package com.cg.tripadvisormvcspringcollection.service;

import java.util.List;

import com.cg.tripadvisormvcspringcollection.dto.Review;
import com.cg.tripadvisormvcspringcollection.exceptions.DestinationDetailNotFoundException;

public interface ReviewService {
	
	public Review addReview(Review review)  ;
	
}

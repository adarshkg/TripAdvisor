/**	@author adgangad
 * project name: TripAdvisor
 * 			This project is about adding destination and writing  review for the destination
 * Three function :-
 * 			
 * 			1.add destination()  [parameters-->Destination destination , return type-->Destination destination]
 *		    2.SearchReviewByDestination() [parameters-->string myDestination,return type---->List of Reviews]
 *			3.SearchDestinationByRating() [parameters-->int rating,return type---->List of Destination]
 * 
 * This class is sending the data to the repository layer and then fetching the details from repository layer
 * */

package com.cg.tripadvisormvcspringcollection.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.tripadvisormvcspringcollection.dto.Destination;
import com.cg.tripadvisormvcspringcollection.dto.Review;
import com.cg.tripadvisormvcspringcollection.exceptions.DestinationDetailNotFoundException;
import com.cg.tripadvisormvcspringcollection.repository.DestinationRepositoryImp;


@Service("destinationService")
@Transactional
public class DestinationServiceImp implements DestinationService{
	
	//public static int destId=0;
	
	
	@Autowired
	 DestinationRepositoryImp destinationrepository;
	
/**
 * @author: adgangad
 * @param: destination
 * @return:- destination(Destination)
 * @throws: DestinationDetailNotFoundException 
 * */
	@Override
	public Destination addDestination(Destination destination) {
		Destination dest=destinationrepository.save(destination);
		//destId++;
		//destination.setId(destId);
		return destinationrepository.save(destination);	
	}


/**
 * 
 * @author adgangad
 * @param:- destination city(String)
 * @return  :- List<Review> 
 * @throws DestinationDetailNotFoundException 

*/
	
	@Override
	public List<Review> SearchReviewByDestination(String myDestination) throws DestinationDetailNotFoundException {
		
		return destinationrepository.findReviewByDestination(myDestination);
	}

	
/**
 * @author adgangad
 * @param:- rating 
 * @return :- List<Destination>
 * @throws DestinationDetailNotFoundException 
 */

	@Override
	public List<Destination> SearchDestinationByRating(int rating) throws DestinationDetailNotFoundException{
		
		List<Destination> dest = destinationrepository.findDestinationByRating(rating);
		if(dest.isEmpty()) {
			throw new DestinationDetailNotFoundException();
		}
		
		return destinationrepository.findDestinationByRating(rating);
	}

	

}

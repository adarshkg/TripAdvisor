/*
 *	@author adgangad
 */
package com.cg.tripadvisormvcspringcollection.service;

import java.util.List;

import com.cg.tripadvisormvcspringcollection.dto.Destination;
import com.cg.tripadvisormvcspringcollection.dto.Review;
import com.cg.tripadvisormvcspringcollection.exceptions.DestinationDetailNotFoundException;

public interface DestinationService {
	public Destination addDestination(Destination destination)  ;
	public List<Destination> SearchDestinationByRating(int rating) throws DestinationDetailNotFoundException ;
	public List<Review> SearchReviewByDestination(String myDestination) throws DestinationDetailNotFoundException ;
}

/**
 *	@author adgangad
 * project name: TripAdvisor
 * 			This project is about adding destination and writing  review for the destination
 * 
 */

package com.cg.tripadvisormvcspringcollection.dto;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;


@Entity
public class Destination {
	@Id
	@GeneratedValue
	@Column(name="dest_id")
	private int id;
	@Column(unique=true,name="dest_city")
	private String city;
	@Column(name="dest_rating")
	private Integer rating;
	@Column(name="dest_country")
	private String country;


	@OneToMany(fetch = FetchType.EAGER,cascade = CascadeType.ALL,orphanRemoval = true, mappedBy="destination")
	private List<Review> review;
	
	public Destination() {
		super();	
	}
	
	public Destination(int id, String city, Integer rating, String country, List<Review> review) {
		super();
		this.id = id;
		this.city = city;
		this.rating = rating;
		this.country = country;
		this.review = review;
	}


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Integer getRating() {
		return rating;
	}
	public void setRating(Integer rating) {
		this.rating = rating;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public List<Review> getReview() {
		return review;
	}
	public void setReview(List<Review> review) {
		this.review = review;
	}

	@Override
	public String toString() {
		return "Destination [city=" + city + ", rating=" + rating + ", country=" + country + ", review=" + review + "]";
	}
	
	
	
	
}

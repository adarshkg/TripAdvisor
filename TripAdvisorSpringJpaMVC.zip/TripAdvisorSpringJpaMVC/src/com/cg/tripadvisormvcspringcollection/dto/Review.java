/*
 *	@author adgangad
 * project name: TripAdvisor
 * 			This project is about adding destination and writing  review for the destination
 * 
 */
package com.cg.tripadvisormvcspringcollection.dto;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import org.hibernate.annotations.OnDelete;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Entity
public class Review {
	@Id
	@Column(name="review_id")
	private  int id;
	@Column(name="review_city")
	private String city;
	@Column(name="review_desc")
	private String description;

	@OneToOne(cascade=CascadeType.ALL)
	private Reviewer reviewer;
	
	@ManyToOne
	@JoinColumn(name="dest_id")
	Destination destination;
	
	public Review(int id, String city, String description, Reviewer reviewer, Destination destination) {
		super();
		this.id = id;
		this.city = city;
		this.description = description;
		this.reviewer = reviewer;
		this.destination = destination;
	}

	public Destination getDestination() {
		return destination;
	}

	public void setDestination(Destination destination) {
		this.destination = destination;
	}

	public Review() {
		super();

	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Reviewer getReviewer() {
		return reviewer;
	}
	public void setReviewer(Reviewer reviewer) {
		this.reviewer = reviewer;
	}
	@Override
	public String toString() {
		return "Review [id=" + id + ", city=" + city + ", description=" + description + ", reviewer=" + reviewer + "]";
	}

}

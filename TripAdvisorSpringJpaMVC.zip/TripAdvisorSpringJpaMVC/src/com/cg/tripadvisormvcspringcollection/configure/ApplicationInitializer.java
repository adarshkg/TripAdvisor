 /** @author adgangad
 * 
 *  dispatcher servlet
 * */



package com.cg.tripadvisormvcspringcollection.configure;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

public class ApplicationInitializer extends AbstractAnnotationConfigDispatcherServletInitializer{

	/**  @author adgangad
	 *   @return  :- AppContexts.class
	 *  
	 * */
	@Override
	protected Class<?>[] getRootConfigClasses() {
		return new Class[] {AppContexts.class};
	}

	/**  @author adgangad
	 *   @return  :- WebMvc.class
	 *  
	 * */
	@Override
	protected Class<?>[] getServletConfigClasses() {
		return new Class[] {WebMvc.class};
	}

	/**  @author adgangad
	 *   @return  :- "/"
	 *  
	 * */
	@Override
	protected String[] getServletMappings() {
		return new String[] {"/"};
	}

	
}

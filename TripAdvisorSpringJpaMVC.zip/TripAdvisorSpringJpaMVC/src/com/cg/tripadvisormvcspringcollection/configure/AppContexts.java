 /** @author adgangad
 * 
 * Configuring database connection
 * */


package com.cg.tripadvisormvcspringcollection.configure;
import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.cg.tripadvisormvcspringcollection.exceptions.DestinationDetailNotFoundException;

@Configuration
@PropertySource("classpath:resources/mysql.properties")
@ComponentScan("com.cg.tripadvisormvcspringcollection")
@EnableTransactionManagement
public class AppContexts {

	@Autowired
	Environment environment ;
	
	/**  @author adgangad
	 *   @return  :- sessionFactory
	 *  
	 * */
	@Bean
	public LocalSessionFactoryBean sessionFactory() {
		LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
		sessionFactory.setDataSource(dataSource());
		sessionFactory.setPackagesToScan(new String[] {"com.cg.tripadvisormvcspringcollection.dto"});
		sessionFactory.setHibernateProperties(hibernateProperties());
		return sessionFactory;
	}
	
	/**  @author adgangad
	 *   @return  :- dataSource
	 *  
	 * 
	 * */
	@Bean
	public DataSource dataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(environment.getRequiredProperty("mysql.driver"));
		dataSource.setUrl(environment.getRequiredProperty("mysql.url"));
		dataSource.setUsername(environment.getRequiredProperty("mysql.username"));
		dataSource.setPassword(environment.getRequiredProperty("mysql.password"));
		return dataSource;
	}
	
	/**  @author adgangad
	 *   @return  :- properties
	 * */
	@Bean
	public Properties hibernateProperties() {
		Properties properties = new Properties();
		properties.put("hibernate.dialect", environment.getRequiredProperty("mysql.dialect"));
		properties.put("hibernate.hbm2ddl.auto", environment.getRequiredProperty("mysql.auto"));
		return properties;
	}
	
	/**  @author adgangad
	 *   @return  :- transactionManager
	 *   
	 * 
	 * */
	@Bean
	public HibernateTransactionManager getTransactionManager() {
		HibernateTransactionManager transactionManager = new HibernateTransactionManager();
		transactionManager.setSessionFactory(sessionFactory().getObject());
		return transactionManager;
	}
	
}

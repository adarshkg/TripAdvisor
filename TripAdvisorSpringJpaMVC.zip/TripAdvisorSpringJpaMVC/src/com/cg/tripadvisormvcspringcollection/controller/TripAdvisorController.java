/**
	 * @author adgangad	 * 
	 * TripAdvisorController - Every request and response from the client and server will map using this controller class 
	 *  
	 * */


package com.cg.tripadvisormvcspringcollection.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.tripadvisormvcspringcollection.dto.Destination;
import com.cg.tripadvisormvcspringcollection.dto.Review;
import com.cg.tripadvisormvcspringcollection.exceptions.DestinationDetailNotFoundException;
import com.cg.tripadvisormvcspringcollection.service.DestinationService;
import com.cg.tripadvisormvcspringcollection.service.ReviewService;


@Controller
public class TripAdvisorController {

	@Autowired
	DestinationService destinationService;
	@Autowired
	ReviewService reviewService;

	/**
	 * @author adgangad	 * 
	 * @return :- "home"
	 *  
	 * */
	@GetMapping("home")
	public String homePage() {
		return "home";
	}

	/**
	 * @author adgangad
	 * @return :- "preAddReview"
	 * @param:- Review review
	 * */
	@GetMapping("preAddReview")
	public ModelAndView preAddReview(@ModelAttribute("rev") Review review) {

		return new ModelAndView("preAddReview");

	}

	/**
	 * @author adgangad
	 * @return :-"addReview"
	 * @param:-  Review review
	 * @exception:- destinationDetailNotFound
	 * */
	@PostMapping("addReview")
	public ModelAndView addReview(@ModelAttribute("rev") Review review) {

		Review rev;
	
			rev = reviewService.addReview(review);
		return new ModelAndView("addReview","key",rev);
	}



	/**
	 * @author adgangad
	 * @return :- "preAddDestination"
	 * @param  Destination destination
	 * */
	@GetMapping("preAddDestination")
	public String preAddDestination(@ModelAttribute("dest") Destination destination) {
		
		return "preAddDestination";
	
	}
	
	/**
	 * @author adgangad
	 * @return :- "addDestination"
	 *  @exception:-destinationDetailNotFound
	 *  @param  Destination destination
	 * */
	@PostMapping("addDestination")
	public ModelAndView addDestination(@ModelAttribute("dest") Destination destination) {

	
			Destination dest = destinationService.addDestination(destination);
		
		return new ModelAndView("addDestination");
	
	}


	/**
	 * @author adgangad
	 * @return :- "showDestination","key",destination
	 * @param  Destination destination
	 * */
	@GetMapping("showDestination")
	public ModelAndView showDestination(@ModelAttribute("dest") Destination destination) {

		return new ModelAndView("showDestination","key",destination);
	
	}
	
	/**
	 * @author adgangad
	 * @return :- "postShowDestination","key",List<Destination> destinations
	 * @exception:-destinationDetailNotFound
	 * @param  Destination destination
	 * */
	@PostMapping("postShowDestination")
	public ModelAndView postShowDestination(@ModelAttribute("dest") Destination destination) {
		
		int rating = destination.getRating();
		List<Destination> destinations;
		try {
			destinations = destinationService.SearchDestinationByRating(rating);
			System.out.println(destinations);
		} catch (Exception e) {
			return new ModelAndView("error");
		}
		return new ModelAndView("postShowDestination","key",destinations);
	}


	/**
	 * @author adgangad
	 * @return :- "showReview"
	 *  @exception:-destinationDetailNotFound
	 * @param  Destination destination
	 * */
	@GetMapping("showReview")
	public ModelAndView showReview(@ModelAttribute("dest") Destination destination) {

		return new ModelAndView("showReview");
	}

	/**
	 * @author adgangad
	 * @return :- "postShowReview","key",List<Review> reviews
	 * @exception:-destinationDetailNotFound
	 * @throws DestinationDetailNotFoundException 
	 * */
	@PostMapping("postShowReview")
	public ModelAndView postShowReview(@ModelAttribute("dest") Destination destination) {

		String city = destination.getCity();
		List<Review> reviews;
		try {
			
			reviews = destinationService.SearchReviewByDestination(city);
		} catch (Exception e) {

			return new ModelAndView("error");
		}
		return new ModelAndView("postShowReview","key",reviews);
		
	}


}

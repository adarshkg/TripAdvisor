/*
 *	@author adgangad
 */
package com.cg.tripadvisormvcspringcollection.repository;

import com.cg.tripadvisormvcspringcollection.dto.Review;
import com.cg.tripadvisormvcspringcollection.exceptions.DestinationDetailNotFoundException;

public interface ReviewRepository {
		public Review save(Review review);
		
}

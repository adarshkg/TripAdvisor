 /*	@author adgangad
 * project name: TripAdvisor
 * 			This is Destination repsoitory interface 
 * 
*/
package com.cg.tripadvisormvcspringcollection.repository;

public interface DestinationQuery {
	
//	query to get destination from the destination table using city
	String querySelectDestinationByCity = "from Destination d where city=?1";
	
//	query to get destination from the destination table using the rating
	String querySelectDestinationByRating= "from Destination d where rating=?1";
}

/*
 *	@author adgangad
 */
package com.cg.tripadvisormvcspringcollection.repository;

import java.util.List;

import com.cg.tripadvisormvcspringcollection.dto.Destination;
import com.cg.tripadvisormvcspringcollection.dto.Review;
import com.cg.tripadvisormvcspringcollection.exceptions.DestinationDetailNotFoundException;

public interface DestinationRepository {
	public Destination save(Destination destination);
	public List<Review> findReviewByDestination(String city) throws DestinationDetailNotFoundException;
	public List<Destination> findDestinationByRating(int rating) throws DestinationDetailNotFoundException;
}

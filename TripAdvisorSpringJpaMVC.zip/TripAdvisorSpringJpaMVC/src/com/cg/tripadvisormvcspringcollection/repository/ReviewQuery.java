 /*	@author adgangad
 * project name: TripAdvisor
 * 			This is review query interface
 * 
*/
package com.cg.tripadvisormvcspringcollection.repository;

public interface ReviewQuery {

//	query to get destination from the destination table using city
	String querySelectDestination = "FROM Destination d WHERE city=?1";

}

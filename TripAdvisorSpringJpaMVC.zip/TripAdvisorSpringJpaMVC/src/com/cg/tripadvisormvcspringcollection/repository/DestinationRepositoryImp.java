/*
 * @author-adgangad
 * 
 * Three functions
 * 		1.save()  [parameters-->Destination destination,return type-->Destination]
 * 		2.findReviewByDestination() -->[parameters-->String city, return type-->List<Review>]
 * 		3.findDestinationByRating() -->[parameters-->int rating, retrun type-->List<Destination>]
 * */



package com.cg.tripadvisormvcspringcollection.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;


import com.cg.tripadvisormvcspringcollection.dto.Destination;
import com.cg.tripadvisormvcspringcollection.dto.Review;
import com.cg.tripadvisormvcspringcollection.exceptions.DestinationDetailNotFoundException;

@Repository
public class DestinationRepositoryImp implements DestinationRepository{	
	
	@PersistenceContext
	EntityManager entitymanager;
/**	save function will accept a destination object from the service layer and save to the destination table
 * 
 * @author adgangad
 * @param:- destination (Destination) 
 * @return  :- destination(Destination)
 * @throws DestinationDetailNotFoundException 
 *  
 *  
 *  
 *  */

	@Override
	public Destination save(Destination destination)  {
		entitymanager.persist(destination);
		entitymanager.flush();
		return destination;
		
		}
		
/**	This function will accept city and find the review and reviewer details regarding that specific destination 
 * 
 *  @author adgangad
 * @param:- String city  
 * @return  :- Review review
 * @throws DestinationDetailNotFoundException 
 * 
 * */

	@Override
	public List<Review> findReviewByDestination(String city) throws DestinationDetailNotFoundException {
	

		List<Review> reviews = new ArrayList<Review>();
		Destination destination = new Destination();
		
//		finding the review.
		TypedQuery<Destination> query = entitymanager.createQuery(DestinationQuery.querySelectDestinationByCity,Destination.class);
		query.setParameter(1, city);	
		destination = query.getSingleResult();
		reviews =destination.getReview();

		return reviews;

	}

/**	this function will find the destinations based on the rating of the destination
 * 
 *  @author adgangad
 * @param:- int rating  
 * @return  :- List<Destination>
 * @throws DestinationDetailNotFoundException 
 *  
 *  */

	@Override
	public List<Destination> findDestinationByRating(int rating) throws DestinationDetailNotFoundException {
	
	
		List<Destination> destinations = new ArrayList<Destination>();
		
		
//		finding the destination cities using the rating of destination
		TypedQuery<Destination> query = entitymanager.createQuery(DestinationQuery.querySelectDestinationByRating,Destination.class);
		query.setParameter(1, rating);
		
		destinations =query.getResultList();
		return destinations;

	}

}

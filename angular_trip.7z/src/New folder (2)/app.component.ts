﻿import { Component } from '@angular/core';
import {FormControl} from '@angular/forms'
import { DestinationService } from './app.destinationservice';
import { Destination } from './app.destination';
@Component({
    selector: 'app',
    templateUrl: 'app.component.html'
})

export class AppComponent { 
    name = new FormControl('');
  

}
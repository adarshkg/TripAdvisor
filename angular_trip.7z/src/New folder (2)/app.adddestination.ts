import { Component,OnInit  } from "@angular/core";
import{DestinationService} from "./app.destinationservice"
import { Destination } from "./app.destination";

import { FormBuilder, FormGroup, Validators,FormControl } from '@angular/forms';
@Component({

    selector:'add-dest',
    templateUrl:'adddestination.html'
})
export class AddDestination implements OnInit{

    ngOnInit(){

    }
    destination:Destination[];

    model = new FormGroup({
        rating: new FormControl(''),
        country: new FormControl('' ),
        city: new FormControl(''),
        review:new FormControl('' )
    })
    constructor(private destservice:DestinationService){}


    adddestination(){
  
        this.destservice.addDestination(this.model).
        subscribe((data:any)=>console.log(data))
    
    }
}
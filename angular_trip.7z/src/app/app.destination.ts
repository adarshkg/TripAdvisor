import { Review } from "./app.review";


 export class Destination{
    country:string;
    city:string;
    rating:number;
    review:Review[];
}
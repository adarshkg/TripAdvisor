import { Component } from "@angular/core";
import { DestinationService } from "./app.destinationservice";
import { Destination } from "./app.destination";
import { FormControl } from "@angular/forms";


@Component({

    selector:'search-dest',
    templateUrl:'searchdestination.html'
})
export class SearchDestination{

     searchResult:Destination[];
     search=new FormControl('');
     constructor(private destinationservice:DestinationService){}

        finddestination()
        {

        this.destinationservice.searchDestination(this.search).
        subscribe((data:any)=>this.searchResult=data)
    

        }


       
}
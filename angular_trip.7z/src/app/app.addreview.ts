import { Component } from "@angular/core";
import { DestinationService } from "./app.destinationservice";
import { FormGroup, Validators, FormBuilder,FormControl } from "@angular/forms";



@Component({

    selector:'add-rev',
    templateUrl:'addreview.html'
})
export class AddReview{

        rev = new FormGroup({
        city:new FormControl(''),
        description:new FormControl(''),
        name:new FormControl(''),
        email:new FormControl('')
    })
    

    constructor(private destservice:DestinationService){}


    addreview(){
        this.destservice.addReview(this.rev).
        subscribe((data:any)=>console.log(data))
    
    }
}
﻿import { Component } from '@angular/core';
import {FormControl} from '@angular/forms'
@Component({
    selector: 'app',
    templateUrl: 'app.component.html'
})

export class AppComponent { 
    name = new FormControl('');
    
}
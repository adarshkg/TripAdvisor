export class Reviewer{
    name:string;
    email:string;
}
import { Component } from "@angular/core";
import { DestinationService } from "./app.destinationservice";
import { Destination } from "./app.destination";
import { FormControl } from "@angular/forms";


@Component({

    selector:'search-rev',
    templateUrl:'searchreview.html'
})
export class SearchReview{

    search = new FormControl('');
    destination={};
    constructor(private destinationservice:DestinationService){}

   
    findreview()
    {

    this.destinationservice.searchReview(this.search).
    subscribe((data:any)=>this.destination=data);

    }
}
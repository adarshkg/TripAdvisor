import { Injectable } from "@angular/core";
import { HttpClient } from '@angular/common/http';
import { Destination } from "./app.destination";
import {Review} from './app.review'
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

@Injectable({
    providedIn: 'root'
})

export class DestinationService {



    destination:Destination[];
    review:Review[];

    constructor(private http: HttpClient) { }



    addDestination(dest:any) {
        let input = new FormData();
        input.append("country",dest.country)
        input.append("city",dest.city)
        input.append("rating",dest.rating)
    
        return this.http.post("http://localhost:9098/tripadvisor/addDestination",input) .pipe(
            retry(1),
            catchError(this.handleError)
          );
    }

    addReview(rev:any) {
        let input = new FormData();
        input.append("city",rev.city)
        input.append("name",rev.name)
        input.append("description",rev.description)
        input.append("reviewer.name",rev.name)
        input.append("reviewer.email",rev.email)
        return this.http.post("http://localhost:9098/tripadvisor/addReview",input) .pipe(
            retry(1),
            catchError(this.handleError)
          );
    }

    searchDestination(dest:any) {
        return this.http.get("http://localhost:9098/tripadvisor/finddestination",{params:{
            rating:dest.rating
        }}) .pipe(
            retry(1),
            catchError(this.handleError)
          );
    }
    searchReview(dest:any) {
        return this.http.get("http://localhost:9098/tripadvisor/findreview",{params:{
            city:dest.city
        }}) .pipe(
            retry(1),
            catchError(this.handleError)
          );
     
        }
        handleError(error) {
            let errorMessage = '';
            if (error.error instanceof ErrorEvent) {
              // client-side error
              errorMessage = `Error: ${error.error}`;
            } else {
              // server-side error
              errorMessage = `Error Code: ${error.status}\nMessage: ${error.error}`;
            }
            window.alert(errorMessage);
            return throwError(errorMessage);
          }
}
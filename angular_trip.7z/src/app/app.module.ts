﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { AddDestination } from './app.adddestination';
import { SearchDestination } from './app.searchdestination';
import { SearchReview } from './app.searchreview';
import { AddReview } from './app.addreview';
import {Routes,RouterModule} from '@angular/router'
import { HttpClientModule } from '@angular/common/http';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import {NgxPaginationModule} from 'ngx-pagination'; 


const route:Routes=[
    {path:"addDestination",component:AddDestination},
    {path:"addReview",component:AddReview},
    {path:"findDestination",component:SearchDestination},
    {path:"findReview",component:SearchReview}
    
]




@NgModule({
    imports: [
        BrowserModule,
        HttpClientModule,
        RouterModule.forRoot(route),
        FormsModule,ReactiveFormsModule,
        NgxPaginationModule
        
    ],
    declarations: [
        AppComponent,
        AddDestination,
        AddReview,
        SearchReview,
        SearchDestination

		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }
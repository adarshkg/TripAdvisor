﻿import { Component } from '@angular/core';
import {FormControl} from '@angular/forms'
import { DestinationService } from './app.destinationservice';
import { Destination } from './app.destination';
@Component({
    selector: 'app',
    templateUrl: 'app.component.html'
})

export class AppComponent { 
    name = new FormControl('');
    test:string;
    error:string;
    dest:Destination[]
    constructor(private destservice:DestinationService){}
    destinationNotFound(){
        this.error=""
        this.destservice.searchDestination(this.test).subscribe((data:Destination[])=>this.dest=data,
        error=>this.error=this.error);
    }
}
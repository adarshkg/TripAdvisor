import { Component,OnInit  } from "@angular/core";
import{DestinationService} from "./app.destinationservice"
import { Destination } from "./app.destination";
import { FormBuilder, FormGroup, Validators,FormControl } from '@angular/forms';
@Component({

    selector:'add-dest',
    templateUrl:'adddestination.html'
})
export class AddDestination implements OnInit{

    // addForm: FormGroup;
    submitted = false;
    model:any={}
        addForm = this.formBuilder.group({
        rating: ['', Validators.required],
        country: ['', Validators.required],
       city: ['', [Validators.required, Validators.email]],
       review: ['']
    });
    ngOnInit(){
     
    }
    destination:Destination[];

    // model = new FormGroup({
    //     rating: new FormControl('', Validators.required),
    //     country: new FormControl('', Validators.required),
    //     city: new FormControl('', Validators.required),
    //     review:new FormControl('', Validators.required)
    // })
    constructor(private destservice:DestinationService,private formBuilder: FormBuilder){}


    adddestination(){
  
        console.log("sss")
        this.model.rating = this.addForm.value.rating;
        console.log(this.model.rating)
        this.destservice.addDestination(this.addForm).
        subscribe((data:any)=>console.log(data))
    
    }
}
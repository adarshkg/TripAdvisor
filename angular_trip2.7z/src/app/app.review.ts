import {Reviewer} from './app.reviewer'

export class Review{
    city:string;
    description:string;
    reviewer:Reviewer;
}